HOSPI LIFE CARE WEBSITE

Files:
- index.html: responsive company website

Company contact details added:
Email: deepak.medtech@gmail.com
Phone: 8800415743
Address: KHASRA NO. 270, SABHA PUR, CHAUHAN PATTI, SHAHDRA, DELHI 110094

Preview:
Open index.html in a web browser.

Publishing:
Upload index.html to your web hosting provider or a static-site host. A domain name and hosting are needed to make the website available publicly.

Enquiry form:
The form prepares an email to deepak.medtech@gmail.com using the visitor's default email application. It does not store submissions on a server.
